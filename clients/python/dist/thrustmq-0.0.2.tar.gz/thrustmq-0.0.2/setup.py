from distutils.core import setup
setup(
  name = 'thrustmq',
  packages = ['thrustmq'],
  version = '0.0.2',
  description = 'Python client to ThrustMQ',
  author = 'Alexander Krasnoschekov',
  author_email = 'akrasnoschekov@gmail.com',
  url = 'https://github.com/rambler-digital-solutions/thrustmq',
  download_url = 'https://github.com/peterldowns/mypackage/tarball/0.0.1',
  keywords = [],
  classifiers = [],
)
